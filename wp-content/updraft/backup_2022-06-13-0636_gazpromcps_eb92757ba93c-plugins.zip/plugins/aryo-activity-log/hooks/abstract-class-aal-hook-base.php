<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Empty class for now..
 * 
 * Class AAL_Hook_Base
 */
abstract class AAL_Hook_Base {
	
	public function __construct() {}
	
}